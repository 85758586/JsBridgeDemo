package com.doweidu.bridgewebviewdemo.utils;


import android.content.Context;
import android.widget.Toast;

import com.doweidu.bridgewebviewdemo.BuildConfig;

/**
 * Description:
 * Author： Created by wz on 2016/6/23.
 */
public class MyAssert {
    public static void assertWithDefaultMessage(Context context, boolean express){
        if (BuildConfig.DEBUG && !express){
            Toast.makeText(context, "assert failed!", Toast.LENGTH_SHORT).show();
        }
    }

    public static void assertWithMessage(Context context, boolean express, String message){
        if (BuildConfig.DEBUG && !express){
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        }
    }
}
