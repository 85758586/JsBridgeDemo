package com.doweidu.bridgewebviewdemo.utils;

import java.util.Arrays;
import java.util.List;

/**
 * Description:
 * Author： Created by wz on 2016/7/4.
 */
public class TextUtils {

    public static boolean isNewVersion(String local, String online){

        Preconditions.checkArgument(local.matches("\\d+\\.\\d+\\.\\d+"));
        Preconditions.checkArgument(online.matches("\\d+\\.\\d+\\.\\d+"));

        String[] localArray = android.text.TextUtils.split(local, ".");
        String[] onlineArray = android.text.TextUtils.split(online, ".");

        int maxLength = localArray.length < onlineArray.length ? localArray.length : onlineArray.length;

        for (int i = 0; i < maxLength; i++){
            if (Integer.parseInt(localArray[i]) < Integer.parseInt(onlineArray[i])){
                return true;
            }else if (Integer.parseInt(localArray[i]) > Integer.parseInt(onlineArray[i])){
                return true;
            }
        }

        return false;
    }
}
