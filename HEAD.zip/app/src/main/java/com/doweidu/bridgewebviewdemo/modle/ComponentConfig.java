package com.doweidu.bridgewebviewdemo.modle;

import java.util.List;

/**
 * Description:
 * Author： Created by wz on 2016/7/4.
 */
public class ComponentConfig {

    private List<ComponentPackage> componentPackages;

    public List<ComponentPackage> getPackageList() {
        return componentPackages;
    }

    public void setPackageList(List<ComponentPackage> componentPackageList) {
        this.componentPackages = componentPackageList;
    }
}
