package com.doweidu.bridgewebviewdemo.modle;

import java.util.List;

/**
 * Description:
 * Author： Created by wz on 2016/7/4.
 */
public class SubConfig {

    private String id;
    private String version;
    private String https;
    private List<ComponentPage> componentPages;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getHttps() {
        return https;
    }

    public void setHttps(String https) {
        this.https = https;
    }

    public List<ComponentPage> getPageList() {
        return componentPages;
    }

    public void setPageList(List<ComponentPage> componentPageList) {
        this.componentPages = componentPageList;
    }
}
