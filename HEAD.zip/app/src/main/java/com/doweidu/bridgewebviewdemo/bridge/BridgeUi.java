package com.doweidu.bridgewebviewdemo.bridge;

import android.support.v7.app.AlertDialog;
import android.view.View;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.doweidu.bridgewebviewdemo.annotations.BridgeClass;
import com.doweidu.bridgewebviewdemo.ui.BridgeWebViewActivity;
import com.doweidu.bridgewebviewdemo.Callback;
import com.doweidu.bridgewebviewdemo.IBridge;
import com.doweidu.bridgewebviewdemo.utils.JSONUtils;

import org.json.JSONObject;

import java.util.Map;

/**
 * Description:
 * Author： Created by wz on 2016/6/30.
 */
@BridgeClass("ui")
public class BridgeUi implements IBridge{

    private static final String PARAM_TITLE = "title";
    private static final String PARAM_MESSAGE = "message";
    private static final String PARAM_CANCEL_BUTTON_TITLE = "cancelButtonTitle";

    public void showLoading(WebView webView, JSONObject param, final Callback callback){
        ProgressBar progressBar = ((BridgeWebViewActivity) webView.getContext()).getProgressBar();
        progressBar.setVisibility(View.VISIBLE);
    }

    public void hideLoading(WebView webView, JSONObject param, final Callback callback){
        ProgressBar progressBar = ((BridgeWebViewActivity) webView.getContext()).getProgressBar();
        progressBar.setVisibility(View.GONE);
    }

    public void showError(WebView webView, JSONObject param, final Callback callback){
        Toast.makeText(webView.getContext(), "错误", Toast.LENGTH_SHORT).show();
    }

    public void hideError(WebView webView, JSONObject param, final Callback callback){

    }

    public void showAlert(WebView webView, JSONObject param, final Callback callback){

        Map<String, String> map = JSONUtils.getStringMapFromJSONObject(param, PARAM_TITLE, PARAM_MESSAGE, PARAM_CANCEL_BUTTON_TITLE);
        String title = map.get(PARAM_TITLE);
        String message = map.get(PARAM_MESSAGE);
        String cancelButtonTitle = map.get(PARAM_CANCEL_BUTTON_TITLE);

        AlertDialog alertDialog = new AlertDialog.Builder(webView.getContext())
                .setTitle(title)
                .setMessage(message)
                .setNegativeButton(cancelButtonTitle, null)
                .create();
        alertDialog.show();
    }

}
