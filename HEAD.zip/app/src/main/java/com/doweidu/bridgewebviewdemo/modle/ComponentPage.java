package com.doweidu.bridgewebviewdemo.modle;

/**
 * Description:
 * Author： Created by wz on 2016/7/4.
 */
public class ComponentPage {

    private String name;
    private String file;
    private boolean login;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public boolean isLogin() {
        return login;
    }

    public void setLogin(boolean login) {
        this.login = login;
    }
}
