package com.doweidu.bridgewebviewdemo;

import android.app.Application;

import com.doweidu.bridgewebviewdemo.bridge.BridgeActionBar;
import com.doweidu.bridgewebviewdemo.bridge.BridgeHttp;
import com.doweidu.bridgewebviewdemo.bridge.BridgePage;
import com.doweidu.bridgewebviewdemo.bridge.BridgeUi;
import com.doweidu.bridgewebviewdemo.manager.BridgeWebViewActivityManager;


/**
 * Description:
 * Author： Created by wz on 2016/6/22.
 */
public class MyApplication extends Application{

    private static MyApplication instance;
    private BridgeWebViewActivityManager bridgeWebViewActivityManager;

    @Override
    public void onCreate() {
        super.onCreate();

        instance = this;
        initJsBridge();
    }

    public static MyApplication getInstance(){
        return instance;
    }

    public BridgeWebViewActivityManager getBridgeWebViewActivityManager() {
        return bridgeWebViewActivityManager;
    }

    private void initJsBridge(){
        bridgeWebViewActivityManager = new BridgeWebViewActivityManager();
        JSBridge.getInstance().register(new BridgePage(), new BridgeActionBar(), new BridgeHttp(), new BridgeUi());

    }
}
