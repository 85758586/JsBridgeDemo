package com.doweidu.bridgewebviewdemo.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.doweidu.bridgewebviewdemo.BridgeWebChromeClient;
import com.doweidu.bridgewebviewdemo.MyApplication;
import com.doweidu.bridgewebviewdemo.R;

public class BridgeWebViewActivity extends AppCompatActivity {

    public static final String INIT_URL = "init_url";
    public static final String PARAMS = "params";
    public static final String PAGE_ORDER = "page_order";

    private ProgressBar progressBar;

    private String initUrl;
    private String params;
    private WebView webView;
    private boolean isInterceptActionBarBackButton;
    private int pageOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bridge_web_view);

        initUrl = getIntent().getStringExtra(INIT_URL);
//        initUrl = "http://m.haoshiqi.net";
        params = getIntent().getStringExtra(PARAMS);
        pageOrder = getIntent().getIntExtra(PAGE_ORDER, 0);

        MyApplication.getInstance().getBridgeWebViewActivityManager().getBridgeWebViewActivityMap().put(pageOrder, this);
//        MyApplication.getInstance().getBridgeWebViewActivityManager().getBridgeWebViewActivityList().add(pageOrder, this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle(getTitle().toString() + pageOrder);
        initWebView();
        progressBar = (ProgressBar) findViewById(R.id.progress_bar);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if (item.getItemId() == android.R.id.home){
            if (isInterceptActionBarBackButton) {
                return true;
            }else {
                onBackPressed();
            }
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onDestroy(){
        MyApplication.getInstance().getBridgeWebViewActivityManager().getBridgeWebViewActivityMap().remove(pageOrder);
//        MyApplication.getInstance().getBridgeWebViewActivityManager().getBridgeWebViewActivityList().remove(this);
        super.onDestroy();
    }

    public String getParams(){
        return params;
    }

    public ProgressBar getProgressBar(){
        return progressBar;
    }

    public void interceptActionBarBackButton(boolean b){
        isInterceptActionBarBackButton = b;
    }

    public int getPageOrder(){
        return pageOrder;
    }

    private BridgeWebViewActivity initWebView(){
        webView = (WebView) findViewById(R.id.web_view);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        webView.setWebChromeClient(new BridgeWebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });
        webView.loadUrl(initUrl);
        return this;
    }



}
