package com.doweidu.bridgewebviewdemo.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

import com.doweidu.bridgewebviewdemo.BridgeWebChromeClient;
import com.doweidu.bridgewebviewdemo.R;
import com.doweidu.bridgewebviewdemo.http.HttpClient;
import com.loopj.android.http.BinaryHttpResponseHandler;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {

//    private static final String ASSETS_URL = "file:///android_asset/test.html";
//    private String testUrl2 = "http://10.0.0.63:8000/test.html";
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        Button button = (Button) findViewById(R.id.btn_open_web_view);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String url;

                EditText input = (EditText)findViewById(R.id.input);
                if (!TextUtils.isEmpty(input.getText().toString())){
                    url = input.getText().toString();
                }else {
                    url = "file:///android_asset/test.html";
                }

                url = "http://10.0.0.73:8000";

                Intent intent = new Intent(MainActivity.this, BridgeWebViewActivity.class);
                intent.putExtra(BridgeWebViewActivity.INIT_URL, url);
                startActivity(intent);
            }
        });

    }




}
