package com.doweidu.bridgewebviewdemo.bridge;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import com.doweidu.bridgewebviewdemo.manager.ComponentManager;
import com.doweidu.bridgewebviewdemo.ui.BridgeWebViewActivity;
import com.doweidu.bridgewebviewdemo.ui.MainActivity;

import org.json.JSONObject;

/**
 * Description:
 * Author： Created by wz on 2016/7/4.
 */
public class BridgePageControllerImpl implements IBridgePageController{

    private static final String QUERY_URL = "url";
    private static final String QUERY_PAGE = "page";
    private static final String QUERY_COMPID = "compid";
    private static final String QUERY_COMPPAGE = "comppage";

    @Override
    public void loadUrl(Context context, Uri uri, JSONObject params) {
        String url = uri.getQueryParameter(QUERY_URL);
        Intent intent = new Intent(context, BridgeWebViewActivity.class);
        intent.putExtra(BridgeWebViewActivity.INIT_URL, url);
        intent.putExtra(BridgeWebViewActivity.PARAMS, params.toString());
        intent.putExtra(BridgeWebViewActivity.PAGE_ORDER, BridgePage.TOTAL_ACTIVITY_NUMBER);
        context.startActivity(intent);
    }

    @Override
    public void loadLocalComponent(Context context, Uri uri, JSONObject params) {
        String componentId = uri.getQueryParameter(QUERY_COMPID);
        String componentPage = uri.getQueryParameter(QUERY_COMPPAGE);
  //      String path = ComponentManager.getInstance().getComponentPagePath(componentId, componentPage);

//        Intent intent = new Intent(context, BridgeWebViewActivity.class);
//        intent.putExtra(BridgeWebViewActivity.INIT_URL, path);
//        intent.putExtra(BridgeWebViewActivity.PARAMS, params.toString());
//        intent.putExtra(BridgeWebViewActivity.PAGE_ORDER, BridgePage.TOTAL_ACTIVITY_NUMBER);
//        context.startActivity(intent);
    }

    @Override
    public void openActivity(Context context, Uri uri, JSONObject params) {
        String page = uri.getQueryParameter(QUERY_PAGE);
        if ("home".equals(page)){
            Intent intent = new Intent(context, MainActivity.class);
            intent.putExtra(BridgeWebViewActivity.PARAMS, params.toString());
            context.startActivity(intent);
        }
    }


}
