package com.doweidu.bridgewebviewdemo.bridge;

import android.webkit.WebView;

import com.doweidu.bridgewebviewdemo.annotations.BridgeClass;
import com.doweidu.bridgewebviewdemo.Callback;
import com.doweidu.bridgewebviewdemo.IBridge;
import com.doweidu.bridgewebviewdemo.http.HttpClient;
import com.doweidu.bridgewebviewdemo.utils.JSONUtils;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

import cz.msebera.android.httpclient.Header;

/**
 * Description:
 * Author： Created by wz on 2016/6/7.
 */
@BridgeClass("http")
public class BridgeHttp implements IBridge{

    private static final String PARAM_URL = "url";
    private static final String PARAM_METHOD = "method";
    private static final String PARAM_PARAMS = "params";

    public void ajax(WebView webView, JSONObject param, final Callback callback){

        Map<String, String> map = JSONUtils.getStringMapFromJSONObject(param, PARAM_URL);
        String url = map.get(PARAM_URL);
        String method = map.get(PARAM_METHOD);
        JSONObject params = JSONUtils.getObjectMapFromJSONObject(param, PARAM_PARAMS).get(PARAM_PARAMS);

        HttpClient.getInstance().getData(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String result = new String(responseBody);

                JSONObject resultJson = new JSONObject();
                try {
                    resultJson.put("result", result);
                }catch (JSONException e){
                    e.printStackTrace();
                }

                callback.callJs(JSONUtils.parseJSONResponse(Callback.SUCCESS, resultJson));
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });

    }
}
