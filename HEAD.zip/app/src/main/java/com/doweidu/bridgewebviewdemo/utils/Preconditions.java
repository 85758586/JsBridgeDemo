package com.doweidu.bridgewebviewdemo.utils;

/**
 * Description:对方法的前置条件进行检查
 * Author： Created by wz on 2016/6/30.
 */
public class Preconditions {

    public static <T> T checkNotNull(T obj) {
        if (obj == null) {
            throw new NullPointerException();
        }
        return obj;
    }

    public static void checkArgument(boolean condition) {
        if (!condition) {
            throw new IllegalArgumentException();
        }
    }
}
