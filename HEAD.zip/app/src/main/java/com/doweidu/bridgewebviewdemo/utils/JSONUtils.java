package com.doweidu.bridgewebviewdemo.utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Description:
 * Author： Created by wz on 2016/6/30.
 */
public class JSONUtils {

    public static Map<String, String> getStringMapFromJSONObject(JSONObject param, String ...keys){
        Map<String, String> paramMap = new HashMap<>();
        String value;

        for (String each : keys){
            try {
                value = param.getString(each);
            }catch (JSONException e){
                e.printStackTrace();
                continue;
            }
            paramMap.put(each, value);
        }

        return paramMap;
    }

    public static Map<String, JSONObject> getObjectMapFromJSONObject(JSONObject param, String ...keys){
        Map<String, JSONObject> paramMap = new HashMap<>();
        JSONObject value;

        for (String each : keys){
            try {
                value = param.getJSONObject(each);
            }catch (JSONException e){
                e.printStackTrace();
                continue;
            }
            paramMap.put(each, value);
        }

        return paramMap;
    }

    public static int getIntFromJSONObject(JSONObject param, String key){
        int value = 0;
        try {
            value = param.getInt(key);
        }catch (JSONException e){
            e.printStackTrace();
        }

        return value;
    }

    //把返回值包装成JSONObject
    public static JSONObject parseJSONResponse(int code, JSONObject result) {
        JSONObject object = new JSONObject();
        try {
            object.put("error", code);
            object.putOpt("result", result);
        } catch (JSONException e) {
            LogUtils.e(e.getMessage());
        }

        return object;
    }

    //把返回值包装成JSONObject
    public static JSONObject parseJSONResponse(int code, String result) {
        JSONObject object = new JSONObject();
        try {
            object.put("error", code);
            object.putOpt("result", result);
        } catch (JSONException e) {
            LogUtils.e(e.getMessage());
        }

        return object;
    }
}
