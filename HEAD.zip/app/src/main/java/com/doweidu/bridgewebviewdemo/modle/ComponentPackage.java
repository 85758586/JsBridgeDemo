package com.doweidu.bridgewebviewdemo.modle;

/**
 * Description:
 * Author： Created by wz on 2016/7/4.
 */
public class ComponentPackage {

    private String id;
    private String version;
    private String url;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
