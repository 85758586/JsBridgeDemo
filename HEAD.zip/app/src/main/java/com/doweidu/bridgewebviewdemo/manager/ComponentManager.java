package com.doweidu.bridgewebviewdemo.manager;

import android.content.SharedPreferences;
import android.os.Environment;
import android.preference.PreferenceManager;

import com.doweidu.bridgewebviewdemo.MyApplication;
import com.doweidu.bridgewebviewdemo.http.HttpClient;
import com.doweidu.bridgewebviewdemo.modle.ComponentConfig;
import com.doweidu.bridgewebviewdemo.modle.ComponentPackage;
import com.doweidu.bridgewebviewdemo.modle.ComponentPage;
import com.doweidu.bridgewebviewdemo.modle.SubConfig;
import com.doweidu.bridgewebviewdemo.utils.MapUtils;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.BinaryHttpResponseHandler;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import cz.msebera.android.httpclient.Header;

/**
 * Description:
 * Author： Created by wz on 2016/7/1.
 */
public class ComponentManager {

    private static final String COMPONENT_CONFIG = "component_config";
    private static ComponentManager instance;

    private Map<String, SubConfig> subConfigMap;

    private ComponentManager(){

    }

    synchronized public static ComponentManager getInstance(){
        if (instance == null){
            instance = new ComponentManager();
        }

        return instance;
    }

    public void loadConfig(){
        HttpClient.getInstance().getData("http://www.baidu.com", new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                ComponentConfig newConfig = initTestData();
                ComponentConfig oldConfig = readLocalConfig();
                checkUpdate(oldConfig, newConfig);
                saveConfig(newConfig);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
    }

    public void downloadComponentPackage(){
        String url = "http://mirrors.hust.edu.cn/apache/maven/maven-3/3.3.9/binaries/apache-maven-3.3.9-bin.zip";
        String[] allowedContentTypes = new String[]{".*"};
        HttpClient.getInstance().downLoadFile(url, new BinaryHttpResponseHandler(allowedContentTypes) {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] binaryData) {
                String zipPath = Environment.getExternalStorageDirectory().getPath() + "/local.zip";
                File file = new File(zipPath);
                if (file.exists()){
                    file.delete();
                }
                try {
                    file.createNewFile();
                    OutputStream stream = new FileOutputStream(file);
                    stream.write(binaryData);
                }catch (IOException e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] binaryData, Throwable error) {
                error.getMessage();
            }
        });
    }

    public ComponentPage  getComponentPage(String id, String name){
        SubConfig subConfig = subConfigMap.get(id);
        if (subConfig != null){
            List<ComponentPage> pages = subConfig.getPageList();
            for (ComponentPage each : pages){
                if (name.equals(each.getName())){
                    return each;
                }
            }
        }

        return null;

    }

    public void deleteComponentPackage(String id){

    }

    public void updateComponentPackage(){

    }

    public ComponentConfig readLocalConfig(){

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(MyApplication.getInstance());
        String config = preferences.getString(COMPONENT_CONFIG, "");
        Gson gson = new Gson();
        return gson.fromJson(config, ComponentConfig.class);
    }

    private void checkUpdate(ComponentConfig oldConfig, ComponentConfig newConfig){
        Map<String, ComponentPackage> oldMap = MapUtils.listToMap(oldConfig.getPackageList());
        Map<String, ComponentPackage> newMap = MapUtils.listToMap(newConfig.getPackageList());

    }

    private void saveConfig(ComponentConfig config){
        Gson gson = new Gson();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(MyApplication.getInstance());
        preferences.edit().putString(COMPONENT_CONFIG, gson.toJson(config)).commit();
    }

    private ComponentConfig initTestData(){

        ComponentPackage package1 = new ComponentPackage();
        package1.setId("package1");
        package1.setUrl("http://www.163.com");
        package1.setVersion("1.0.0");
        ComponentPackage package2 = new ComponentPackage();
        package2.setId("package2");
        package2.setUrl("http://www.sina.com.cn");
        package2.setVersion("1.0.1");
        ArrayList<ComponentPackage> packages = new ArrayList<>();
        packages.add(package1);
        packages.add(package2);
        ComponentConfig componentConfig = new ComponentConfig();
        componentConfig.setPackageList(packages);

        return componentConfig;
    }
}
