package com.doweidu.bridgewebviewdemo.bridge;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;

import com.doweidu.bridgewebviewdemo.annotations.BridgeClass;
import com.doweidu.bridgewebviewdemo.ui.BridgeWebViewActivity;
import com.doweidu.bridgewebviewdemo.Callback;
import com.doweidu.bridgewebviewdemo.IBridge;
import com.doweidu.bridgewebviewdemo.MyApplication;
import com.doweidu.bridgewebviewdemo.utils.JSONUtils;

import org.json.JSONObject;

import java.util.List;
import java.util.Map;

/**
 * @Description:
 * @Author Created by wz on 2016/6/3.
 */
@BridgeClass("page")
public class BridgePage implements IBridge {

    public static int TOTAL_ACTIVITY_NUMBER;

    private static final String PARAM_URL = "url";
    private static final String PARAM_TYPE = "type";
    private static final String PARAMS = "params";
    private static final String PARAM_REVERT = "revert";
    private static final String PATH_URL = "url";
    private static final String PATH_COMPONENT = "component";
    private static final String PATH_NATIVE = "native";
    private static final String SCHEME_HAO = "duoweidu";
    private static final int TYPE_NEW = 1;
    private static final int TYPE_THIS = 2;

    private Map<Integer, JSONObject> activityParamMap;
    private Map<Integer, BridgeWebViewActivity> bridgeWebViewActivityMap;
    private IBridgePageController pageController;

    public BridgePage(){
        activityParamMap = MyApplication.getInstance().getBridgeWebViewActivityManager().getActivityParamMap();
        bridgeWebViewActivityMap = MyApplication.getInstance().getBridgeWebViewActivityManager().getBridgeWebViewActivityMap();
        pageController = new BridgePageControllerImpl();
    }


    public void start(WebView webView, JSONObject param, final Callback callback){
        TOTAL_ACTIVITY_NUMBER++;
        activityParamMap.put(TOTAL_ACTIVITY_NUMBER, param);

        String url = JSONUtils.getStringMapFromJSONObject(param, PARAM_URL).get(PARAM_URL);
        int type = JSONUtils.getIntFromJSONObject(param, PARAM_TYPE);
        JSONObject params = JSONUtils.getObjectMapFromJSONObject(param, PARAMS).get(PARAMS);

        if (type == TYPE_NEW) {
            parseScheme(webView.getContext(), url, params);
        }else {
            webView.loadUrl(url);
        }


    }

    public void back(WebView webView, JSONObject param, final Callback callback){
        int backCount = JSONUtils.getIntFromJSONObject(param, PARAM_REVERT);
        int thisActivityOrder = ((BridgeWebViewActivity)webView.getContext()).getPageOrder();
        int thatActivityOrder = thisActivityOrder + backCount;

        for (int i = thisActivityOrder; i > thatActivityOrder; i--){
            BridgeWebViewActivity activity = bridgeWebViewActivityMap.get(i);
            if (activity != null){
                activity.finish();
                bridgeWebViewActivityMap.remove(i);
                activityParamMap.remove(i);
                TOTAL_ACTIVITY_NUMBER--;
            }
        }

        BridgeWebViewActivity activity = bridgeWebViewActivityMap.get(thatActivityOrder);
        JSONObject thatActivityParam = activityParamMap.get(thatActivityOrder);
        if (activity == null){
            if (thatActivityParam == null){
                return;
            }

            String url = JSONUtils.getStringMapFromJSONObject(thatActivityParam, PARAM_URL).get(PARAM_URL);
            JSONObject params = JSONUtils.getObjectMapFromJSONObject(thatActivityParam, PARAMS).get(PARAMS);
            String content = JSONUtils.getStringMapFromJSONObject(thatActivityParam, "intent").get("intent");

            Intent intent = new Intent(webView.getContext(), BridgeWebViewActivity.class);
            intent.putExtra(BridgeWebViewActivity.INIT_URL, url);
            intent.putExtra(BridgeWebViewActivity.PARAMS, content);
            intent.putExtra(BridgeWebViewActivity.PAGE_ORDER, thatActivityOrder);
            webView.getContext().startActivity(intent);
        }
    }

    public void params(WebView webView, JSONObject param, final Callback callback){
        String params = ((BridgeWebViewActivity) webView.getContext()).getParams();

        callback.callJs(JSONUtils.parseJSONResponse(Callback.SUCCESS, params));
    }

    private void parseScheme(Context context, String url, JSONObject params){
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme();
        String path = uri.getPath();
        String query = uri.getQuery();
        String[] subQuery = query.split("url=");
//        String test1 = query.substring(query.indexOf("url=") + 1, query.length());
//        String testUrl = subQuery[1];
        if (SCHEME_HAO.equals(scheme)){
            switch (path){
                case PATH_URL:
                    pageController.loadUrl(context, uri, params);
                    break;
                case PATH_COMPONENT:
                    pageController.loadLocalComponent(context, uri, params);
                    break;
                case PATH_NATIVE:
                    pageController.openActivity(context, uri, params);
                    break;
            }
        }

    }
}
