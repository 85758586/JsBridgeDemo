package com.doweidu.bridgewebviewdemo.utils;

import com.doweidu.bridgewebviewdemo.modle.ComponentPackage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * Author： Created by wz on 2016/7/4.
 */
public class MapUtils {

    public static <T extends ComponentPackage> Map<String, T> listToMap(List<T> list){
        Map<String, T> map = new HashMap<>();
        for (T each : list){
            map.put(each.getId(), each);
        }

        return map;
    }
}
