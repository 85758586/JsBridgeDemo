package com.doweidu.bridgewebviewdemo.manager;

import com.doweidu.bridgewebviewdemo.ui.BridgeWebViewActivity;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * Author： Created by wz on 2016/7/1.
 */
public class BridgeWebViewActivityManager {

    private Map<Integer, JSONObject> activityParamMap;
    private Map<Integer, BridgeWebViewActivity> bridgeWebViewActivityMap;

//    private List<BridgeWebViewActivity> bridgeWebViewActivityList;

    public BridgeWebViewActivityManager(){
        activityParamMap = new HashMap<>();
        bridgeWebViewActivityMap = new HashMap<>();
//        bridgeWebViewActivityList = new ArrayList<>();
    }

    public Map<Integer, JSONObject> getActivityParamMap() {
        return activityParamMap;
    }

    public Map<Integer, BridgeWebViewActivity> getBridgeWebViewActivityMap() {
        return bridgeWebViewActivityMap;
    }

//    public List<BridgeWebViewActivity> getBridgeWebViewActivityList() {
//        return bridgeWebViewActivityList;
//    }
}
