package com.doweidu.bridgewebviewdemo.bridge;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;

import com.doweidu.bridgewebviewdemo.annotations.BridgeClass;
import com.doweidu.bridgewebviewdemo.annotations.BridgeMethod;
import com.doweidu.bridgewebviewdemo.ui.BridgeWebViewActivity;
import com.doweidu.bridgewebviewdemo.Callback;
import com.doweidu.bridgewebviewdemo.IBridge;
import com.doweidu.bridgewebviewdemo.utils.JSONUtils;

import org.json.JSONObject;

/**
 * Description:
 * Author： Created by wz on 2016/6/7.
 */
@BridgeClass("header")
public class BridgeActionBar implements IBridge{

    private static final String PARAM_TITLE = "title";

    @BridgeMethod("setTitle")
    public void setActivityTitle(WebView webView, JSONObject param, final Callback callback){
        String title = JSONUtils.getStringMapFromJSONObject(param, PARAM_TITLE).get(PARAM_TITLE);

        ActionBar actionBar = ((AppCompatActivity)webView.getContext()).getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle(title);
        }
    }

    @BridgeMethod("back")
    public void onActionBarBack(WebView webView, JSONObject param, final Callback callback){
        ((BridgeWebViewActivity) webView.getContext()).interceptActionBarBackButton(true);

        callback.callJs(JSONUtils.parseJSONResponse(Callback.SUCCESS, callback.getmCallbackId()));
    }

}
