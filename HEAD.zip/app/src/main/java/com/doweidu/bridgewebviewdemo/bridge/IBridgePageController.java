package com.doweidu.bridgewebviewdemo.bridge;

import android.content.Context;
import android.net.Uri;

import org.json.JSONObject;

/**
 * Description:
 * Author： Created by wz on 2016/7/4.
 */
public interface IBridgePageController {
    void loadUrl(Context context, Uri uri, JSONObject params);
    void loadLocalComponent(Context context, Uri uri, JSONObject params);
    void openActivity(Context context, Uri uri, JSONObject params);
}
