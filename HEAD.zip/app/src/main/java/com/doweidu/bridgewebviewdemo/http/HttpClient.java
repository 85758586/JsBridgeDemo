package com.doweidu.bridgewebviewdemo.http;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.BinaryHttpResponseHandler;

/**
 * Description:
 * Author： Created by wz on 2016/6/30.
 */
public class HttpClient {
    private static HttpClient instance;
    private AsyncHttpClient asyncHttpClient;

    private HttpClient(){
        asyncHttpClient = new AsyncHttpClient();
    }

    synchronized public static HttpClient getInstance(){
        if (instance == null){
            instance = new HttpClient();
        }

        return instance;
    }

    public void getData(String url, AsyncHttpResponseHandler handler){
        asyncHttpClient.get(url, handler);
    }

    public void downLoadFile(String url, BinaryHttpResponseHandler handler){
        asyncHttpClient.get(url, handler);
    }
}
