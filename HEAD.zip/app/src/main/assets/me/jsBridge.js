(function (){
  if (window.dwd) {
    return false;
  }
  
  /***************************************
  *  (private) 存储注册的ready事件的队列
  ***************************************/ 
  var readyCallback = [];

  /***************************************
  *  (public) 定义jsbridge，所有方法将挂在该空间下对外爆露
  ***************************************/ 
  var dwd = {
    version: '0.1',

    /**
     * {boolean} 页面信息及DOM加载状态，全部加载完成为true，默认完成为false
     */
    isAllReady: false,

    /**
    *  (publick)注册jsb ready事件的方法
    *  @param   {function}  callback ready时的回调方法
    *  @return  {number}    注册事件在回调堆栈中的位置
    */
    ready: function(callback) {
      if(callback && typeof callback == "function") {
        return readyCallback.push(callback);
      }
      return false;
    }
  };

  /***************************************
  *  (private) {object} js与na交互过程中的错误号
  ***************************************/ 
  var ERROR_NUM = {
    OK: 0,
  };

  /***************************************
  *  (public)native中定义的方法在jsb中的映射
  *  该映射后的方法包含参数验证、调用native功能
  ***************************************/ 
  var dwd_ = {
    /*
    *  参数验证规则：
    *
    *    {
    *      "[参数1名称]": "[是否必传（＋）][参数类型]",
    *      "[参数2名称]": "[是否必传（＋）][参数类型]",
    *      "[参数3名称]": "[是否必传（＋）][参数类型]",
    *      ...
    *    }
    */
    "page": {
      "start": {"url": "+string", "type": "number", "params": "object"},
      "back": {"revert": "number"},
      "params": {},
    },
    "header": {
      "setTitle": {"title": "string"},
      "back": {}
    },
    "http": {
      "ajax": {"url": "+string", "method": "string", "params": "object", "success": "function", "fail": "function"}
    },
    "ui": {
      "showError": {},
      "hideError": {},
      "showLoading": {},
      "hideLoading": {},
      "showAlert": {"title": "+string", "message": "string", "cancelButtonTitle": "string" },
    },

    /**
    *  (publick)生成基本方法
    *  @param   {string}    moudle 方法所属模块名
    *  @param   {string}    method 方法名
    *  @param   {object}    paramsFormat 方法的参数验证规则
    *  @return  {function}  生成的方法
    */
    function_: function(moudle, method, paramsFormat) {
      return function() {
        // 调用时参数均采用json形式传入
        var args = {};
        var index = 0;
        for(var key in paramsFormat) {
          var format = paramsFormat[key];
          var arg = (typeof arguments[0] != "object") ? arguments[index] : arguments[0][key];
          var msg = "";

          if (arg) {
            format = format.replace("+", "");
            if(typeof arg != format) {
              msg = "[ERROR]:arguments " + key + " must be '" + format + "'!";
            }
            args[key] = arg;
          } else if(format.indexOf("+") >= 0) {
            msg = "[ERROR]:arguments " + key + " not found!";
          }

          if(msg != "") {
            console.error(msg);
            return false;
          }
          index++;
        }

        bridge.callNative(moudle + "." + method, args);
      };
    },
    
    /**
    *  (private)遍历配置的规则，生成方法
    */
    init: function() {
      for(var moudle in this) {
        if (typeof this[moudle] == "object") {
          for(var method in this[moudle]) {
            if(typeof this[moudle][method] != "function") {
              this[moudle][method] = this.function_(moudle, method, this[moudle][method]);
            }
          }
        }
      }

      this.purify();
      return this;
    },

    /**
    *  (private)剔除内部方法，保证对外爆露的借口的整洁性
    */
    purify: function() {
      delete this.methodList;
      delete this.init;
      delete this.purify;
    }
  }.init();

  /***************************************
  *  (private)内部使用的一些公用方法
  ***************************************/ 
  var _ = {
    /**
    *  合并两个对象，合并深度为一层，deep＝1，合并结果会存在第一个参数中，同时也会返回
    *  @param  {}  callback ready时的回调方法
    *  @return  {object}  合并后的对象
    */
    extend: function() {
      var obj, rel = arguments[0];
      for (var i = 1, len = arguments.length; i < len; i++) {
        obj = arguments[i];
        if (typeof obj == "object") {
          for(var key in obj) {
            rel[key] = obj[key];
          }
        }
      }

      return rel;
    }
  };

  /****************************************
  *  (private)使用JS进行设备检测的模块
  *  由于hybrid初始化时需要判断设备来调用不同的借口，故使用js进行判断
  ***************************************/ 
  var detect = {
    // 浏览器用户标识
    ua: navigator.userAgent.toLowerCase(),
    // 是否为ios设备
    isIos: false,
    // 是否为安卓设备
    isAndroid: false,
    // 设备的系统：ios、android
    platform: '',
    /**
    *  初始化
    */
    init: function() {
      this.isIos = (this.ua.indexOf('iphone') > -1) || (this.ua.indexOf('iphone') > -1);
      this.isAndroid = (this.ua.indexOf('android') > -1 || this.ua.indexOf('linux') > -1);
      this.platform = this.isAndroid ? "android" :
                      this.isIos ? "ios" : "other";

      delete this.init;
      return this;
    }
  }.init();

  /****************************************
  *  (private)js与native通信的基本方法
  ***************************************/ 
  var bridge = {
    /**
    *  不同环境下，调用native的不同方法
    *  @param  {string}  method  需要调用的功能
    *  @param  {object}  params  调用功能时需要的参数
    *  @param  {number}  callbackId  回调函数存放的id
    */
    callNativeList: {
      ios: function(method, params, callbackId) {
        var iframe = document.createElement("iframe");
        iframe.style.display = "none";
        document.body.appendChild(iframe);
        iframe.src = 'jsapi://_?' + 'method=' + method +
                     '&params=' + encodeURIComponent(JSON.stringify(params)) + 
                     '&callbackId=' + callbackId;

        setTimeout(function () {
            iframe.parentNode.removeChild(iframe);
        }, 0);
      },
      android: function(method, params, callbackId) {
        var resultStr = prompt('callNative', 
                               '{"method":"' + method +
                               '","params":"' + encodeURIComponent(JSON.stringify(params)) +
                               '","callbackId":"' + callbackId + '"}');
      },
      other: function(method, params, callbackId) {
      }
    }[detect.platform || "other"],

    /**
    *  存放回调函数的堆栈，内部结构为：
    *  [{
    *    "success": <成功时的回调>(function),
    *    "fail": <失败时的回调>(function),
    *    "callback": <对于事件类的回调>(function)
    *  }]
    */
    nativeCallback: [],

    /**
    *  js调用native公用的方法
    *  @param  {string}  method  需要调用的功能
    *  @param  {object}  options  调用功能时需要的参数
    */
    callNative: function (method, options){
      var _option = {
        params: {},
        success: function() {},
        fail: function() {}
      }

      _.extend(_option, options);

      var callbackId = this.nativeCallback.push({
        "success": _option.success,
        "fail": _option.fail,
        "callback": _option.callback
      }) - 1;

      delete _option.success;
      delete _option.fail;
      this.callNativeList && this.callNativeList(method, _option, callbackId);
    },

    /**
    *  native回调js公用的方法
    *  @param  {string}  params  返回的数据
    *  @param  {object}  callbackId  调用时注册的回调函数id
    */
    callJs: function (params, callbackId) {
      alert(params);
      var callbackFc = this.nativeCallback[callbackId];
      var callback = null;

      if (!callbackFc) {
        return false;
      }

      params = decodeURIComponent(params);
      try {
        params = JSON.parse(params);
      } catch(e) {}

      if(params.error == ERROR_NUM.OK) {
        callback = callbackFc.success;
      } else {
        callback = callbackFc.fail;
      }

      if (callbackFc.callback) {
        callback = callbackFc.callback;
      } else {
        delete callbackFc.success;
        delete callbackFc.fail;
        this.nativeCallback.splice(callbackId, 1);
      }

      callback &&
      typeof callback == "function" &&
      callback(params);
    }
  };

  window.dwd = _.extend(dwd, dwd_, bridge, {detect: detect});
})();