package com.doweidu.bridgewebviewdemo;

import android.text.TextUtils;
import android.webkit.WebView;

import com.doweidu.bridgewebviewdemo.annotations.BridgeClassAnnotationProcessor;
import com.doweidu.bridgewebviewdemo.annotations.BridgeMethodAnnotationProcessor;
import com.doweidu.bridgewebviewdemo.utils.LogUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Description:通过反射获得注册类的所有public方法，再根据Scheme进行匹配，匹配成功则调用该方法。
 * Author： Created by wz on 2016/6/3.
 */
public class JSBridge {

    private static final String METHOD = "method";
    private static final String PARAMS = "params";
    private static final String CALLBACK_ID = "callbackId";
    private static final String DEFAULT_CHARSET = "UTF-8";

    private static JSBridge instance;

    private Map<String, Object> bridgeObjectMap = new HashMap<>();                      //保存注册的对象
    private Map<String, HashMap<String, Method>> exposedMethods = new HashMap<>();      //保存注册对象的方法


    private JSBridge(){

    }

    synchronized public static JSBridge getInstance(){
        if (instance == null){
            instance =  new JSBridge();
        }

        return instance;
    }

    /**
    *把多个需要javascript调用的对象注册到Bridge中，如果类没有使用注解，则默认使用类名的小写作为注册名
    *@param bridgeObjects 实现了IBridge接口的类
    */

    public void register(IBridge ...bridgeObjects){
        for (IBridge each : bridgeObjects){
            String regName = BridgeClassAnnotationProcessor.getBridgeName(each.getClass());
            if (TextUtils.isEmpty(regName)){
                String[] classNames = each.getClass().getName().toLowerCase().split("\\.");
                regName = classNames[classNames.length - 1];
            }
            register(regName, each);
        }
    }

    private void register(String exposedName, IBridge bridgeObject) {
        bridgeObjectMap.put(exposedName, bridgeObject);
        if (!exposedMethods.containsKey(exposedName)) {
            try {
                exposedMethods.put(exposedName, getAllMethod(bridgeObject.getClass()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    //java给Js发送通知
    public void notifyJs(WebView webView) {
        String execJs = String.format(Callback.CALLBACK_JS_FORMAT, "user click back button.", -1);

        if (webView != null) {
            webView.loadUrl(execJs);
        }
    }

    //解析传入的Scheme，调用对应注册类的方法
    String callJava(WebView webView, String protocol, String scheme) {
        //解析Scheme
        String className = "";
        String methodName = "";
        int callbackId = 0;
        JSONObject params = new JSONObject();

        if (!TextUtils.isEmpty(scheme) ) {
            try {
                JSONObject object = new JSONObject(scheme);
                String[] method = object.getString(METHOD).split("\\.");
                className = method[0];
                methodName = method[1];
                callbackId = object.getInt(CALLBACK_ID);
                params = new JSONObject(URLDecoder.decode(object.getString(PARAMS), DEFAULT_CHARSET));
            }catch (JSONException | UnsupportedEncodingException e){
                LogUtils.e(e.getMessage());
            }
        }

        //匹配
        if (exposedMethods.containsKey(className)) {
            HashMap<String, Method> methodHashMap = exposedMethods.get(className);
            Object bridgeObject = bridgeObjectMap.get(className);

            if (methodHashMap != null && methodHashMap.size() != 0 && methodHashMap.containsKey(methodName)) {
                Method method = methodHashMap.get(methodName);

                if (method != null) {
                    try {
                        method.invoke(bridgeObject, webView, params, new Callback(webView, callbackId));
                    } catch (Exception e) {
                        LogUtils.e(e.getMessage());
                    }
                }
            }
        }

        return "";
    }

    //获得类的所有公共方法
    private HashMap<String, Method> getAllMethod(Class injectedCls) throws Exception {
        HashMap<String, Method> methodsMap = new HashMap<>();
        Method[] methods = injectedCls.getDeclaredMethods();
        for (Method method : methods) {
            String name;
            String regName = BridgeMethodAnnotationProcessor.getBridgeMethodName(method);
            if (TextUtils.isEmpty(regName)){
                name = method.getName();
            }else {
                name = regName;
            }

            if (method.getModifiers() != (Modifier.PUBLIC) || name == null) {
                continue;
            }
            Class[] parameters = method.getParameterTypes();
            if (null != parameters) {
                methodsMap.put(name, method);
            }
        }
        return methodsMap;
    }


}
