package com.doweidu.bridgewebviewdemo;

import android.net.Uri;
import android.webkit.JsPromptResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

import com.doweidu.bridgewebviewdemo.utils.AssetFileHelper;
import com.doweidu.bridgewebviewdemo.utils.LogUtils;

/**
 * Description:
 * 1.注入本地的Js文件
 * 2.在onJsPrompt中接受Js端传递过来的消息。
 * Created by wz on 2016/6/3.
 */
public class BridgeWebChromeClient extends WebChromeClient {

    public static final String JS_PREFIX = "javascript:";

    private static final String LOCAL_JS_PATH = "jsBridge.js";

    private boolean isInjectedJS;           //JS文件是否已经注入

    @Override
    public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
        LogUtils.d(defaultValue);
        result.confirm(JSBridge.getInstance().callJava(view, message, defaultValue));
        return true;
    }

    @Override
    public void onProgressChanged (WebView view, int newProgress) {
        if (newProgress <= 25) {
            isInjectedJS = false;
        } else if (!isInjectedJS) {
            view.loadUrl(JS_PREFIX + AssetFileHelper.getLocalJS(view, LOCAL_JS_PATH));
            isInjectedJS = true;
        }
        super.onProgressChanged(view, newProgress);
    }

}
