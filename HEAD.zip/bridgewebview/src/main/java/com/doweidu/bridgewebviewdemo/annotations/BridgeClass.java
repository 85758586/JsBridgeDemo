package com.doweidu.bridgewebviewdemo.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Description:在需要注册到JSBridge的类上标注此注解，参数为注册后的名称
 * Author： Created by wz on 2016/6/30.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface BridgeClass {
    String value() default "";
}
