package com.doweidu.bridgewebviewdemo.utils;

import android.content.Context;
import android.view.View;

import com.doweidu.bridgewebviewdemo.utils.LogUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Description: 读取assets文件夹下的文件，并用String的形式返回。本工程中用来读取本地的JsBridge文件
 * Author Created by wz on 2016/6/3.
 */
public class AssetFileHelper {

    /**
    *从assets中读取Js文件
    *@param view webView
    *@param path Js文件路径
    *@return String 读取后的Js文件
    */
    public static String getLocalJS(View view, String path){
        LogUtils.d("jsFile: ", assetFileToString(view.getContext(), path));
        return assetFileToString(view.getContext(), path);
    }

    private static String assetFileToString(Context context, String url){
        InputStream inputStream = null;
        try{
            inputStream = context.getAssets().open(url);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            StringBuilder stringBuilder = new StringBuilder();
            do {
                line = bufferedReader.readLine();
                if (line != null && !line.matches("^\\s*\\/\\/.*")) {
                    stringBuilder.append(line);
                }
            } while (line != null);

            bufferedReader.close();
            inputStream.close();

            return stringBuilder.toString();
        } catch (Exception e) {
            LogUtils.e(e.getMessage());
        } finally {
            if(inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    LogUtils.e(e.getMessage());
                }
            }
        }
        return "";
    }

}
