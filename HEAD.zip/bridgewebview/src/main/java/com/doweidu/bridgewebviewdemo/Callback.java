package com.doweidu.bridgewebviewdemo;

import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;

import com.doweidu.bridgewebviewdemo.utils.LogUtils;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.URLEncoder;

/**
 * Description:本类封装了Native调用JS方法的实现，并按约定，对返回值进行了格式化处理。
 * Author Created by wz on 2016/6/3.
 */
public class Callback {

    public static final int SUCCESS = 0;

    public static final String CALLBACK_JS_FORMAT = "javascript:dwd.callJs('%s', %s);";
    private static final String DEFAULT_CHARSET = "UTF-8";
    private static Handler mHandler = new Handler(Looper.getMainLooper());

    private int mCallbackId;
    private WeakReference<WebView> mWebViewRef;

    public Callback(WebView view, int callbackId) {
        mWebViewRef = new WeakReference<>(view);
        mCallbackId = callbackId;
    }

    public int getmCallbackId() {
        return mCallbackId;
    }

    //java调用Js中的方法
    public void callJs(JSONObject jsonObject) {
        String execJs = "";
        try {
            String result = URLEncoder.encode(String.valueOf(jsonObject), DEFAULT_CHARSET);
            execJs = String.format(CALLBACK_JS_FORMAT, result, mCallbackId);
        }catch (UnsupportedEncodingException e){
            LogUtils.e(e.getMessage());
        }
        if (mWebViewRef != null && mWebViewRef.get() != null) {
            final String finalExecJs = execJs;
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    mWebViewRef.get().loadUrl(finalExecJs);
                }
            });
        }
    }

}
