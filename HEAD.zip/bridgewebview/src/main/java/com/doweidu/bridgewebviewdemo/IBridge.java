package com.doweidu.bridgewebviewdemo;

/**
 * Description：作为约定，要注册到JSBridge的类，需要实现此空接口作为标志。
 * Author Created by wz on 2016/6/3.
 */
public interface IBridge {
}
