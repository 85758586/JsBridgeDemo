package com.doweidu.bridgewebviewdemo.annotations;

import java.lang.reflect.Method;

/**
 * Description:
 * Author： Created by wz on 2016/7/1.
 */
public class BridgeMethodAnnotationProcessor {

    public static String getBridgeMethodName(Method method){
        BridgeMethod name = method.getAnnotation(BridgeMethod.class);
        if (name != null){
            return name.value();
        }

        return "";
    }
}
