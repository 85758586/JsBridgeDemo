package com.doweidu.bridgewebviewdemo.annotations;

/**
 * Description:解析BridgeName注解
 * Author： Created by wz on 2016/6/30.
 */
public class BridgeClassAnnotationProcessor {

    public static String getBridgeName(Class<?> clazz){
        BridgeClass name = clazz.getAnnotation(BridgeClass.class);
        if (name != null){
            return name.value();
        }

        return "";
    }
}
